import styled from "styled-components";

const OverviewIndex = () => {
  return (
    <OverviewContainer>
      <h1>test</h1>
    </OverviewContainer>
  )
};

const OverviewContainer = styled.div`
  background-color: lightgray;
`;
export default OverviewIndex;
